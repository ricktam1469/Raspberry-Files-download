This folder contains the dockerfile samples to use the root file system to create a publishing and subscribing docker images

Replace $ARCH with either armhf or x86_64 in the instructions below
1. copy the corresponding $ARCH rootfs file to the same directory as the dockerfile
2. docker build -t alpine-$ARCH-pub:latest -f Dockerfile.pub .
3. docker build -t alpine-$ARCH-sub:latest -f Dockerfile.sub .

The ARM images thus generated need to be used on an ARM device.

It is assumed that these generated docker images would be uploaded to the Edge Manager to be pushed to the Edge device.

