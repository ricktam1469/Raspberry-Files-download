/*
 * Copyright (c) 2016 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * testmain.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: 212437077
 */

#include <exception>
#include <iostream>
#include <thread>
#include <chrono>
#include "IDatabusClient.h"

static const std::string SAMPLE_TOPIC = "databus_sample_topic";

class SampleDatabusSubscriber : public IDatabusCallback
{
    private:
        IDatabusClient* client;
        int createDatabusClient();
        int reconnectDatabusClient();
        bool connectionStale;
        std::string configFileName;
        bool done;
    public:
     //Callback methods needed by DatabusCallback
     //onMessage callbacks for receiving messages subscribed to
     void onMessage(const std::string& topic,const std::list<PDataValue>& data);
     //Optionally receive connection events
     void onConnection(const IDatabusClient&, int state, int reason);
     //application processing
     int  processMessages();
     bool isDone() {return done;}

    SampleDatabusSubscriber(const std::string& configfile);
    ~SampleDatabusSubscriber();

};

SampleDatabusSubscriber::~SampleDatabusSubscriber()
{
    if (client != NULL)
      delete client;
}

SampleDatabusSubscriber::SampleDatabusSubscriber(const std::string& configfile)
{
    client = NULL;
    this->configFileName=configfile;
    this->createDatabusClient();
    done=false;
}
int SampleDatabusSubscriber::createDatabusClient()
{
   int retval = 0;
    try
     {
             connectionStale = false;
             client=IDatabusClient::createDatabusClient(this->configFileName);
             client->setConnectCallback(this);
             retval = 1;
     }
     catch(const char* e)
     {
             throw e;
     }
     return retval;

}
void SampleDatabusSubscriber::onConnection(const IDatabusClient&, int state, int reason)
{
    if (state == IDatabusClient::DISCONNECTED)
    {
            std::cout << "Received disconnect with reason " << reason << std::endl;
            this->connectionStale=true;
    }
    else if (state == IDatabusClient::CONNECTED)
    {
            if (connectionStale == true)
            {
                std::cout << "Reconnecting with broker" << std::endl;

                delete this->client;
                this->createDatabusClient();
                this->processMessages();
            }
    }
}


void SampleDatabusSubscriber::onMessage(const std::string& topic,const std::list<PDataValue>& data)
{
        std::cout << "Received data for topic: " << topic << std::endl;
        for (PDataValue value: data)
        {
            std::cout << "Message Received: " << value.getValue().c_str() << std::endl;
            if (value.getValue().compare("quit")==0)
            {
                done=true;
            }
        }
}

int SampleDatabusSubscriber::processMessages()
{
    std::cout << "Ready to receive messages on topic " << SAMPLE_TOPIC << std::endl;
    std::cout << "Application will exit on receiving the message 'quit'" << std::endl;
    std::cout << "Press ^C any time to exit. " << std::endl;
    std::list<std::string> topics;
    topics.push_back(SAMPLE_TOPIC);
    client->subscribeData(this,topics, NULL);

    return 0;
}

int main (int argc, char **argv)
{
    SampleDatabusSubscriber *app = NULL;
    try
    {
        //Create sample application instance which will create a databus connection
	app = new SampleDatabusSubscriber("dbconfig.txt");
	if (app != NULL)
	{
	      //start application processing
	      app->processMessages();
	      //Loop until a terminate message is received
	      while(!app->isDone())
	      {
	            std::this_thread::sleep_for (std::chrono::milliseconds (2000));

	      }
	}
    }
    catch(const char* e)
    {
        std::cout << e << std::endl;
    }
    if (app != NULL)
    {
        delete app;
    }
    return 0;
}

