/*
 * Copyright (c) 2016 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * testmain.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: 212437077
 */
#include <exception>
#include <iostream>
#include <thread>
#include <list>
#include <chrono>
#include "IDatabusClient.h"
#include "PDataValue.h"

static const std::string SAMPLE_TOPIC = "databus_sample_topic";
class SampleDatabusPublisher
{
    private:
        IDatabusClient* client;
        int createDatabusClient();
        std::string configFileName;
    public:
     int  processMessages();

    SampleDatabusPublisher(const std::string& configfile);
    ~SampleDatabusPublisher();

};

SampleDatabusPublisher::~SampleDatabusPublisher()
{
    if (client != NULL)
      delete client;
}

SampleDatabusPublisher::SampleDatabusPublisher(const std::string& configfile)
{
    client = NULL;
    this->configFileName=configfile;
    this->createDatabusClient();
}
int SampleDatabusPublisher::createDatabusClient()
{
   int retval = 0;
    try
     {
            client=IDatabusClient::createDatabusClient(this->configFileName);
             retval = 1;
     }
     catch(const char* e)
     {
             throw e;
     }
     return retval;

}

int SampleDatabusPublisher::processMessages()
{
    std::list<PDataValue> values;
    std::cout <<  "Ready to publish data on topic "<< SAMPLE_TOPIC <<  std::endl;
    for (int i =0 ; i < 1000; i++)
    {
    	std::string line = "hello " + std::to_string(i);
        std::cout << "Sending message : " << line << std::endl;
        PDataValue *pv = new PDataValue ("SampleNode", new PEnvelope (new StringValue (line)));
        values.push_back (*pv);
        this->client->publishData (SAMPLE_TOPIC, values);
        values.clear();
        std::this_thread::sleep_for(std::chrono::milliseconds (1000));
    }
    return 0;
}

int main (int argc, char **argv)
{
    SampleDatabusPublisher *app = NULL;
    try
    {
        //Create sample application instance which will create a databus connection
	app = new SampleDatabusPublisher("dbconfig.txt");
	if (app != NULL)
	{
	      //start application processing
	      app->processMessages();

	}
    }
    catch(const char* e)
    {
        std::cout << e << std::endl;
    }
    if (app != NULL)
    {
        delete app;
    }
    return 0;
}

