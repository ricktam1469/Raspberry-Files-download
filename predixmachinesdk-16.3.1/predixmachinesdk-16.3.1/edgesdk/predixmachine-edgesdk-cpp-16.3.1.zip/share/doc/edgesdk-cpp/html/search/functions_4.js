var searchData=
[
  ['setconnectcallback',['setConnectCallback',['../class_i_databus_client.html#a4eff8132efd5ddec5171dcdf8113b5b4',1,'IDatabusClient']]],
  ['setname',['setName',['../class_p_data_value.html#a91e93a550f11e9e7c6dd54c6e2c566dc',1,'PDataValue']]],
  ['subscribedata',['subscribeData',['../class_i_databus_client.html#a999b7c38c6aa18db4342848181f48638',1,'IDatabusClient::subscribeData(IDatabusCallback *cb, const std::string topic, void *)=0'],['../class_i_databus_client.html#a2aa2c0ecd23418314f4b8aa538b2ecc2',1,'IDatabusClient::subscribeData(IDatabusCallback *cb, const std::list&lt; std::string &gt; topics, void *)=0']]]
];
