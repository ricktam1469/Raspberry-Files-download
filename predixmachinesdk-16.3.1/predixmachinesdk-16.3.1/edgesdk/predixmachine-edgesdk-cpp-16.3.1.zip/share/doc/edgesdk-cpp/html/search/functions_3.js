var searchData=
[
  ['penvelope',['PEnvelope',['../class_p_envelope.html#adf3f4a3b2eaf036de360e5c309fff9f4',1,'PEnvelope::PEnvelope(const std::string &amp;type, const std::string &amp;pvalue)'],['../class_p_envelope.html#a5adebecc9928a913bdcd0c36b39242b3',1,'PEnvelope::PEnvelope(PValue *pv)']]],
  ['publishdata',['publishData',['../class_i_databus_client.html#aa3da9d96d9a4cd1c55fbcbf173f87ae5',1,'IDatabusClient']]]
];
