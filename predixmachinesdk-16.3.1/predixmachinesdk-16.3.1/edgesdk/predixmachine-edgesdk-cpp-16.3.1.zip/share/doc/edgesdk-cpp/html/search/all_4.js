var searchData=
[
  ['getname',['getName',['../class_p_data_value.html#ad9b852f52b4175a6cb37d791719015ad',1,'PDataValue']]],
  ['gettype',['getType',['../class_p_value.html#ad614b19f874c3c742af4910d586c3e90',1,'PValue']]]
];
