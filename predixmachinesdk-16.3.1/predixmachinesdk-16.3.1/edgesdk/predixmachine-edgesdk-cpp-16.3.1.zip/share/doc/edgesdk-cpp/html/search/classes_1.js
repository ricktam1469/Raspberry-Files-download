var searchData=
[
  ['doublevalue',['DoubleValue',['../class_double_value.html',1,'']]]
];
