var searchData=
[
  ['type',['type',['../class_p_value.html#ad68b4cd429b5498c61536ebe3197fe05',1,'PValue']]]
];
