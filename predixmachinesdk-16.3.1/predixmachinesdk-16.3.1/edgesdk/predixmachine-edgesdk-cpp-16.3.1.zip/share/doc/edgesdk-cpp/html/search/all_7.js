var searchData=
[
  ['onconnection',['onConnection',['../class_i_databus_callback.html#ac7735d4834cbb045d0c3de73f53c93aa',1,'IDatabusCallback']]],
  ['onmessage',['onMessage',['../class_i_databus_callback.html#a6ee3c49017b3709aee1ab01d1356602c',1,'IDatabusCallback']]]
];
