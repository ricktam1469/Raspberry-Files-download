var searchData=
[
  ['createdatabusclient',['createDatabusClient',['../class_i_databus_client.html#a44bb9214c8b519eefac698c9997cca28',1,'IDatabusClient']]]
];
