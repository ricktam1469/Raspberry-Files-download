This readme describes the usage of the predixmachine-edgesdk-cpp artifacts. There are two artifacts
1. Development:  predixmachine-edgesdk-cpp-rootfs-alpine-*.tar.gz
2. Runtime: predixmachine-edgesdk-cpp-alpine-linux-*-release-shared.tar.gz


1. Using the Development Artifact to create a build and development environment for predixmachine-edgesdk-cpp.

These instructions are for x86_64. They could be used for armhf by replacing x86_64 with armhf.
* Import the rootfs to docker engine.
    # docker import predixmachine-edgesdk-cpp-rootfs-alpine-x86_64.tar.gz edgesdk-cpp-x86_64:dev

* Once imported, just like running any other docker container you can mount your source code path
volume into a running docker instance and initiate its build.. following is an example.


// hwcode.cpp
#include <iostream>

int main()
{
    std::cout << "Hello World!" << std::endl;
    return 0;
}

Assuming the source is in the current working directory, issue the following to compile

# docker run --rm -ti -v $(pwd):/src edgesdk-cpp-x86_64:dev sh -c "cd /src && make hwcode"

to run or debug

# docker run --rm -ti -v $(pwd):/src edgesdk-cpp-x86_64:dev sh -c "/src/hwcode"

# docker run --rm -ti -v $(pwd):/src edgesdk-cpp-x86_64:dev sh -c "gdb /src/hwcode"


2. Using the Runtime Artifact to create a docker container for runtime

To create a docker container for runtime envrionment you do not need the SDK which includes .h and .a files.. 
however you do need to ensure that the run-time shared ".so" libraries are installed in your run-time container.

In case of predixmachine-edgesdk-cpp the runtime components are mosquitto-libs++ pkg and libmsgq++.so* files
in the lib directory of predixmachine-edgesdk-cpp-alpine-linux-x86_64-release-shared.tar.gz. These files are
to be copied to /usr/local/lib or a similar location were your application can find at runtime.

