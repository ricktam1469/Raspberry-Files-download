/*
 * Copyright (c) 2016 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * DataBusComm.h
 *
 *  Created on: Aug 13, 2016
 *      Author: 212437077
 */

#ifndef DATABUSCLIENT_H_
#define DATABUSCLIENT_H_
#include <string>
#include <list>
#include "PDataValue.h"

class IDatabusClient;

/**
 * Interface class for receiving callbacks from the Databus Client library
 * for connection change events and message arrivals
 */
class IDatabusCallback
{
public:

        /**
         * Method called back from the Databus client library when a message arrives
         * @param topic topic for which the data was received
         * @param data received as a list of PDataValue objects
         * @returns
         */
        virtual void onMessage(const std::string& topic,const std::list<PDataValue>& data);
        /**
         * Method called back from the Databus client library for connection events
         * @param state CONNECTED or DISCONNECTED
         * @param reason reason for state change
         * @param data received as a list of PDataValue objects
         * @returns
         */
        virtual void onConnection(const IDatabusClient&, int state, int reason);
        virtual ~IDatabusCallback();
};

/**
 * Abstract class that provides Databus client functionality.
 * Use the createDatabusClient factory method to create a concrete Databus client
 */
class IDatabusClient
{
 public:
        /**
         * Constants for connection events state argument provided to the onConnection callback
         */
        static const int CONNECTED;
        static const int DISCONNECTED;
        IDatabusClient ();
    virtual ~IDatabusClient();

        /**
         * Factory method for creating a Databus client
         * @param configFileName [optional] name of configuration file
         * @returns IDatabusClient handle to Databus client object
         */
	static IDatabusClient * createDatabusClient(std::string configFileName="");

	/**
	 * Sets connection callback for receiving connection events
	 * @param IDatabusCallback object implementing the IDatabusCallback interface
	 */
	virtual void setConnectCallback(IDatabusCallback* cb)=0;

        /**
         * method to subscribe to data published on the Databus
         * @param IDatabusCallback pointer to object of class implementing the callback interface
         * @param topic topic to subscribe to
         * @return return code from the subscription call
         */
	virtual int subscribeData(IDatabusCallback* cb, const std::string topic, void *)=0;
        /**
         * method to subscribe to data published on the Databus
         * @param IDatabusCallback pointer to object of class implementing the callback interface
         * @param topics list of topics to subscribe to
         * @return return code from the subscription call
         */
	virtual int subscribeData(IDatabusCallback* cb, const std::list<std::string> topics, void *)=0;
        /**
         * method to publish structured Machine data to the Databus
         * @param topic topic to publish the data on
         * @param data data to publish as a list of PDataValue objects
         * @return return code from publish
         */
	virtual int publishData(const std::string &topic, const std::list<PDataValue> &data)=0;
};



#endif /* DATABUSCLIENT_H_ */
