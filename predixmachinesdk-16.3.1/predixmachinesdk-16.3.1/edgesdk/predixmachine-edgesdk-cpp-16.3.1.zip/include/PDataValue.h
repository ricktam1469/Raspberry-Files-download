/*
 * Copyright (c) 2016 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

/*
 * PDataValue.h

 *
 *  Created on: Aug 14, 2016
 *      Author: 212437077
 */

#ifndef PDATAVALUE_H_
#define PDATAVALUE_H_
#include <string>
#include <list>
#include <iostream>


/**
 * PValue holds a single value
 */
class PValue
{
protected:
        /**
         * Actual type of the data value
         */
	std::string type;
public:
	/**
	 * Get string representation of type
	 * @return type of the value object
	 */
        std::string getType()
        {
            return type;
        }
        virtual ~PValue ()
        {
        }

        /**
         * Get string representation of the value
         * @return string representation
         */
    virtual std::string to_string()=0;

};

/**
 * Envelope to hold a value object
 */
class PEnvelope
{
	PValue *value;
public:
	/**
	 * Create a value object
	 * @param type string representatiopn of object type
	 * @param pvalue string representation of value
	 */
	PEnvelope(const std::string &type, const std::string &pvalue);
        /**
         * Create a value object
         * @param type string representatiopn of object type
         * @param pv value object to use
         */
       // PEnvelope(const std::string& type, PValue *pv);
        /**
         * Create a value object
         * @param type string representatiopn of object type
         * @param pv value object to use
         */
        PEnvelope(PValue *pv);

	std::string getValue();
	PValue&      getValueObj();

	std::string getType();

	~PEnvelope();

};

class PDataValue
{
    private:
        std::string name;
        PEnvelope *value;
        std::string timestamp;
        std::string quality;
        std::string address;
        std::string category;
    public:

        /**
         * Data types
         */
        static const std::string INTEGER_TYPE;
        static const std::string STRING_TYPE;
        static const std::string BOOLEAN_TYPE;
        static const std::string FLOAT_TYPE;
        static const std::string DOUBLE_TYPE;

        /**
         * Key strings for PDataValue
         */
        static const std::string KEY_NAME;
        static const std::string KEY_VALUE;
        static const std::string KEY_TYPE;
        static const std::string KEY_TIMESTAMP;
        static const std::string KEY_QUALITY;
        static const std::string KEY_ADDRESS;
        static const std::string KEY_CATEGORY;



    public:
        PDataValue ();
        PDataValue (std::string name, PEnvelope value, std::string timestamp,
                    std::string quality, std::string address, std::string category);
        PDataValue (std::string name, PEnvelope *value);

        std::string to_string();

        virtual ~PDataValue ();
        PDataValue(const PDataValue&);
        /**
         * Getter methods for PDataValue fields
        */
        std::string getName();
        std::string getAddress();
        std::string getQuality();
        std::string getCategory();
        std::string getTimestamp();
        std::string getType();
        std::string getValue();

        /**
         * Setter methods for PDataValue fields
         */
        void setName (const std::string& s);
        void setAddress(const std::string& s);
        void setQuality(const std::string& s);
        void setCategory(const std::string& s);
        void setTimestamp(const std::string& s);
        void setTimestamp(uint64_t u);
        void setValue(const std::string& type, const std::string& pvalue);
        void setValue(const std::string& type, PValue *pv);
        void setValue(PValue *pv);

};

class IntValue : public PValue
{
        int value;
    public:
        IntValue(int i);

        IntValue(std::string s);

        std::string  to_string();
        int          getIntValue();

};

class StringValue : public PValue
{
	std::string value;
public:
	StringValue(std::string s);

	std::string to_string();
	std::string getStringValue();

};

class BooleanValue : public PValue
{
	bool value;
public:
        BooleanValue(bool b);
	BooleanValue(std::string s);
	std::string to_string();
	bool        getBooleanValue();

};

class FloatValue : public PValue
{
        float value;
    public:
        FloatValue (float f);

        FloatValue (std::string s);

        std::string  to_string ();
        float        getFloatValue();

};

class DoubleValue : public PValue
{
        double value;
    public:
        DoubleValue (double d);
        DoubleValue (std::string s);
        std::string      to_string ();
        double           getDoubleValue();
};
std::list<PDataValue>* PDataFromJSON(std::string json);
std::string jsonFromPData(const std::list<PDataValue>& values);

#endif /* PDATAVALUE_H_ */
